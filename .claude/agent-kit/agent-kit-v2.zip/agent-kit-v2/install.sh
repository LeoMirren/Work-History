#!/usr/bin/env bash
# Installs agent kit v2 into ~/.claude. Safe to run again.
# Any file it replaces is first copied to ~/.claude/backups/agent-kit-<time>/.
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="${KIT_DEST:-$HOME/.claude}"
BK="$DEST/backups/agent-kit-$(date +%Y%m%d-%H%M%S)"

backup() { # path under DEST
  rel="${1#"$DEST"/}"
  mkdir -p "$BK/$(dirname "$rel")"
  cp -Rp "$1" "$BK/$rel"
}

put() { # src dest
  if [ -e "$2" ]; then
    if cmp -s "$1" "$2"; then echo "unchanged:  $2"; return; fi
    backup "$2"
    echo "replaced:   $2 (old copy in backups)"
  else
    echo "installed:  $2"
  fi
  mkdir -p "$(dirname "$2")"
  cp "$1" "$2"
}

mkdir -p "$DEST"

put "$SRC/agents/evaluator.md" "$DEST/agents/evaluator.md"
put "$SRC/agents/planner.md"   "$DEST/agents/planner.md"
for s in build-loop setup-repo improve-skills fanout; do
  put "$SRC/skills/$s/SKILL.md" "$DEST/skills/$s/SKILL.md"
done
put "$SRC/skills/setup-repo/repo-CLAUDE.md" "$DEST/skills/setup-repo/repo-CLAUDE.md"
put "$SRC/bin/fast-check.sh" "$DEST/bin/fast-check.sh"
put "$SRC/bin/run-repos.sh"  "$DEST/bin/run-repos.sh"
chmod +x "$DEST/bin/fast-check.sh" "$DEST/bin/run-repos.sh"

# Remove the v1 skill that this version replaces.
if [ -d "$DEST/skills/learn-from-run" ]; then
  backup "$DEST/skills/learn-from-run"
  rm -rf "$DEST/skills/learn-from-run"
  echo "removed:    $DEST/skills/learn-from-run (v1, old copy in backups)"
fi

mkdir -p "$DEST/feedback"
[ -e "$DEST/feedback/inbox.md" ] || printf '# Feedback inbox\nOne line per correction: what I said and why.\n\n' > "$DEST/feedback/inbox.md"
[ -e "$DEST/repos.txt" ] || printf '# One absolute repo path per line. Used by run-repos.sh and /improve-skills.\n' > "$DEST/repos.txt"

merge_note=""
if [ ! -e "$DEST/CLAUDE.md" ]; then
  put "$SRC/CLAUDE.md" "$DEST/CLAUDE.md"
elif cmp -s "$SRC/CLAUDE.md" "$DEST/CLAUDE.md" || [ "$(head -n 1 "$DEST/CLAUDE.md")" = "# Working agreement (all repos)" ]; then
  # Same file, or the v1 kit's file: replace it.
  put "$SRC/CLAUDE.md" "$DEST/CLAUDE.md"
else
  cp "$SRC/CLAUDE.md" "$DEST/CLAUDE.agent-kit.md"
  merge_note="yes"
fi

echo
if [ -n "$merge_note" ]; then
  echo "You have your own $DEST/CLAUDE.md, so it was left alone."
  echo "The kit's version is $DEST/CLAUDE.agent-kit.md. Merge it by hand:"
  echo "delete the old lines it replaces (keep-going lines, token budgets,"
  echo "bare never rules, use-subagents lines), then paste it in."
  echo
fi
if [ -e "$DEST/LESSONS.md" ]; then
  echo "Note: $DEST/LESSONS.md from v1 is no longer read. Delete it when you like."
  echo
fi
echo "Next:"
echo "  1. Start a new Claude Code session and run:  /effort high"
echo "  2. In each repo, run once:                   /setup-repo"
echo "  3. List your repo paths in:                  $DEST/repos.txt"
