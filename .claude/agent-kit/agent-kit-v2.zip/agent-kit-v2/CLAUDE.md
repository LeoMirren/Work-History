# How I work

I'm a solo developer running Claude Code across many repos, often unattended (headless runs, /goal, /loop, scheduled tasks). Each repo's own CLAUDE.md has its commands and conventions and wins where it differs from this file. When nobody is there to answer a question, take the most reasonable reading, note the choice in your report, and continue.

## Finished means shown to work
- Work is finished when you can point to evidence: the command you ran and its output, a screenshot, or an evaluator report.
- Use the repo's own checks. Run a check after the change it covers, and run it again only if you change something it covers. A passing result stays valid until then.
- For a feature, a fix that spans several files, or a refactor, use the build-loop skill without waiting to be asked. It writes the contract, builds, and gets a verdict from the evaluator subagent, which has not seen your reasoning. Small local edits (a rename, copy text, a config value) only need the repo's checks.
- Reviewers always find something. Fix findings that affect correctness or the agreed contract, and list the rest in your report.

## Size the effort to the task
- Before a long run, decide what done looks like and how much work it deserves. A one-line fix takes minutes. A feature gets the build loop, which allows at most three evaluator rounds.
- If two attempts at the same problem fail the same way, change the approach or stop and report what you learned. A third identical attempt rarely works.
- Delegate when work splits into independent parts or needs a fresh reviewer. Do small lookups yourself: a subagent costs more and starts without your context.

## Long tasks keep state in files
- For work that may outlive one session, use `.agent/<task>/`: `contract.md` (numbered, checkable criteria) and `progress.json` (one entry per round: what you tried, what the evaluator found, what fixed it, status). Progress is JSON because agents overwrite JSON less often than Markdown.
- When resuming, read `progress.json` first. Keep `.agent/` out of git by adding it to `.git/info/exclude`.

## Approvals
Go ahead without asking on routine work: reading, editing, running tests and builds, installing dev dependencies, local commits and branches, and updating my own pull requests and issues.
Ask me before: pushing to main or a release branch, deleting files you did not create in this task, running migrations or touching production data, publishing a package, or emailing or messaging other people. An approval covers the action I named, not the whole category. In an unattended run, skip those actions and list them in your report so I can do them.

## Learning across sessions
- Repo-specific facts belong in auto memory.
- When I correct you in a way that would apply in other repos too, append one line to `~/.claude/feedback/inbox.md` with what I said and why. Changes to this file and to skills go through /improve-skills, which I review.
- If a note in memory tells you to avoid something and its reason no longer holds, say so and drop it.

## Reports
End each task with a report that makes sense to someone who saw none of the work. Lead with the outcome, then what you did, the evidence it works, what is unfinished or risky, and the next step. Use plain words and full sentences, no labels you made up during the work, and bullets only for separate items. List every file you changed, including small changes.
