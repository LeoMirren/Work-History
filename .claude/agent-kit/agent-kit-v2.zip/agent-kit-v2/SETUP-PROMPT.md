# Setup prompt

Open Claude Code in your home folder and paste everything in the block below.
It assumes this zip is in `~/Downloads` and that the `gh` command is installed
and logged in.

```text
Set up my agent kit everywhere. Work through this once, in order.

1. Install it: run `cd ~ && unzip -o ~/Downloads/agent-kit-v2.zip && bash ~/agent-kit-v2/install.sh`. If it says I already have my own ~/.claude/CLAUDE.md, merge the kit's version into it the way its message describes and show me the result.

2. List my repos with `gh repo list --limit 200 --json nameWithOwner,isFork,isArchived`. Skip forks and archived repos.

3. For each remaining repo, use my local clone if there is one (look in ~/code, ~/Projects, ~/Developer, ~/Documents and ~/Desktop). Otherwise clone it into ~/code. Then, on a new branch named agent-kit-setup:
   - Follow the steps in ~/.claude/skills/setup-repo/SKILL.md. These repos are all mine, so keep the ownership sentence. Do not stop to ask me questions. Where that file says to show me proposed changes, put them in the pull request description instead.
   - Copy ~/.claude/agents/evaluator.md, ~/.claude/agents/planner.md and the ~/.claude/skills/build-loop folder into the repo's .claude/ folder, so the loop also works in cloud sessions and on my other Mac.
   - Commit, push the branch and open a pull request. Do not push to the default branch.
   - Add the repo's local path to ~/.claude/repos.txt.

Limits: one pass per repo. Run each command once. If a repo fails a step (it will not clone, it has uncommitted changes, or none of its commands work), skip it and move on without retrying. Do not re-check repos that are finished. Stop when every repo is either done or skipped.

4. Finish with one table: repo, then its pull request link or the reason it was skipped.
```
