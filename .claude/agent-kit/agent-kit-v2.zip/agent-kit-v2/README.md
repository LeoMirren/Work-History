# Agent kit v2 for Claude Code (Fable 5.2)

Makes Claude Code, in every repo, build to a written contract, get judged by
an independent evaluator, loop until it passes, and work through a task queue
on its own. Built from the Anthropic workshop transcript, the Fable 5.2
prompting guide, and the Claude Code docs.

## Install

    unzip agent-kit-v2.zip && cd agent-kit-v2 && bash install.sh

Installs into `~/.claude`. Anything it replaces is copied to
`~/.claude/backups/` first. It upgrades the v1 kit in place. If you have your
own `~/.claude/CLAUDE.md`, it is left alone and the kit's version is saved
next to it for you to merge.

## How you use it

Once:
1. New Claude Code session, run `/effort high`.
2. In each repo, run `/setup-repo`. It confirms the repo's commands, writes
   the repo CLAUDE.md, adds the fast-check Stop hook, and creates
   `.agent/queue.md`.
3. Put your repo paths in `~/.claude/repos.txt`, one per line.

After that, you write tasks instead of prompts:
- Add lines like `- [ ] add rate limiting to the upload endpoint` to a
  repo's `.agent/queue.md`.
- Run `~/.claude/bin/run-repos.sh`. Each repo with a waiting task gets one
  headless Claude Code run that takes the first task through the build loop
  and marks it `- [x]` done or `- [!]` blocked.
- To make it constant, schedule that script (cron, or a Desktop scheduled
  task that runs it). Repos with nothing waiting cost nothing.

In an interactive session you do not need to type anything special: the
global CLAUDE.md tells the agent to use the build loop on its own for
features, multi-file fixes and refactors. To keep one session going until a
condition holds, use `/goal <condition>, or stop after 40 turns`.

Other commands:
- `/fanout <task>`: wide parallel work (the "graph") as a dynamic workflow.
- `/improve-skills`: weekly. Reads the feedback inbox and evaluator reports,
  shows at most 3 small edits to your instructions, applies what you approve.
- `run-repos.sh -c "<condition>" /path/a /path/b`: same goal in several repos.

## What is in it

| File | What it does |
|---|---|
| `CLAUDE.md` | 30 lines, loaded every session. Context and standards, no "keep going" block, no bare "never" rules |
| `agents/evaluator.md` | Judges work against the contract by running it. Cannot edit files, cannot spawn agents, 40 turns maximum |
| `agents/planner.md` | Turns a vague request into a spec. Read-only, 25 turns maximum |
| `skills/build-loop` | Contract, build, evaluate, fix. Stops on full pass, on no progress, or after round 3 |
| `skills/setup-repo` | One-time repo preparation |
| `skills/improve-skills` | Reviewed self-improvement of the instruction files |
| `skills/fanout` | Parallel work with cross-checking |
| `bin/fast-check.sh` | Stop-hook helper: blocks "done" while the repo's fast check fails |
| `bin/run-repos.sh` | Headless runner across repos with turn, spend and attempt caps |

## Hard limits

| Limit | Enforced by |
|---|---|
| 3 evaluator rounds, stop when a round fixes nothing | build-loop skill |
| Evaluator 40 turns, planner 25 turns | `maxTurns` in the agent files |
| 60 turns and 10 dollars per headless run | `--max-turns`, `--max-budget-usd` |
| 40 turns inside a goal | the clause in the `/goal` condition |
| 2 runs per queue task, then it is marked blocked | run-repos.sh |
| One run per repo at a time, 3 repos at once | run-repos.sh lock and `MAX_PARALLEL` |
| Fast check: skipped if nothing changed since it last passed, gives up after 5 failures in a row, 120 second timeout | fast-check.sh |

The limits live in scripts and frontmatter where the agent cannot argue with
them. The model is never shown a token budget, because Anthropic's guide
found that a displayed budget raised cost without improving results.

## What changed from v1, and why

- Removed the "Keep going" section. Claude Code's best-practices page lists
  that kind of line as a cause of over-work, and Claude Code reportedly
  already sends its own finishing instructions for Fable 5.2.
- Removed the global LESSONS.md. A notes file that every session reads and
  every run appends to is the caution pile-up the Fable 5.2 guide warns
  about. Repo facts now go to Claude Code's built-in auto memory. Changes to
  instructions go through `/improve-skills` with your approval, which is how
  Warp does it in Anthropic's write-up.
- Progress is JSON, not Markdown. The workshop found agents overwrite
  Markdown state more readily.
- The evaluator returns its report as a message and has no write tools. It
  also reviews the contract before building starts, as in the workshop.
- Added a no-progress exit and a rebuild-instead-of-patch rule.
- Added deterministic caps and the Stop hook.
- Added the task queue and headless runner, so work continues without
  prompts.

## Tested and not tested

Tested here: the installer (fresh, re-run, upgrade from v1, existing
CLAUDE.md), `fast-check.sh` in a real git repo, and `run-repos.sh` with a
stand-in for the `claude` command. Every flag and frontmatter field name the
kit uses exists in Claude Code 2.1.323.

Not tested: a real run. No agent has executed these skills. Check these on
your first run:

1. `/memory` shows both CLAUDE.md files, and `/agents` lists evaluator and
   planner.
2. After `/setup-repo`, break the fast check on purpose and ask for a small
   change. The Stop hook should send the error back.
3. Give the queue one small task and run `run-repos.sh`. Confirm
   `contract.md`, `progress.json` and `eval-1.md` appear under `.agent/`,
   and read the `.jsonl` trace in `.agent/runs/` end to end.
4. Unknowns to watch: how `--max-turns` interacts with `/goal`, whether
   `--permission-mode auto` approves everything the loop needs, whether
   headless runs from cron can reach your login, and whether `/fanout`
   starts a real workflow or falls back to subagents.

The round, turn and spend numbers are starting values. Change them after
reading a few traces.
