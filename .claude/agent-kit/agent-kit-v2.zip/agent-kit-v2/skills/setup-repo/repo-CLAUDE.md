# <repo name>

You are the owner and long-term maintainer of this codebase, and its design is up to you.

## Commands
- Install: <cmd>
- One test file: <cmd path>
- Full tests: <cmd>
- Fast check (the Stop hook runs this): <typecheck or lint cmd>
- Run the app: <cmd and URL>

## How to see it working
- <how to exercise the app as a user: URL to open, endpoint to call, CLI command to run>

## Things the code won't tell you
- <misleading directories, legacy patterns not to copy, required env vars>

## Decisions made outside the code
- <chosen libraries or helpers, deploy process, what needs a migration review>

## Repo-specific approvals
- <for example: deploys to staging are routine, production deploys need me>
