---
name: setup-repo
description: Prepares a repo for unattended agent work. Writes its CLAUDE.md, adds a fast-check Stop hook, and creates the task queue. Run once per repo.
disable-model-invocation: true
---
Prepare this repo so agents can work in it without being prompted. One pass. Run each command once.

1. Learn the repo. Read the package files, scripts, CI config and README. Find the commands for: install, one test file, the full tests, a fast check (typecheck or lint), and running the app. Run each one once to confirm it works. Note any that fail on a clean tree.

2. CLAUDE.md. If the repo has none, write one from the template at `${CLAUDE_SKILL_DIR}/repo-CLAUDE.md`. Fill in only what you confirmed, delete sections you have nothing for, and keep it under 60 lines. If one exists, do not rewrite it. Show me proposed changes instead: add missing commands, remove what an agent can read from the code, remove "think hard" and "keep going" lines and token budgets, and turn bare "never" rules into rules with a scope and a reason.

3. Ownership. Ask me once whether this repo is mine to restructure. Keep the ownership sentence from the template only if I say yes. If nobody answers, leave it out.

4. Fast check hook. Pick the fastest reliable check that finishes in under a minute and passes on a clean tree. Add this Stop hook to `.claude/settings.json`, merging with whatever is already there, with the real command in place of `<fast check>`:

   ```json
   {
     "hooks": {
       "Stop": [
         {
           "hooks": [
             {
               "type": "command",
               "command": "f=\"$HOME/.claude/bin/fast-check.sh\"; [ -x \"$f\" ] || exit 0; \"$f\" '<fast check>'"
             }
           ]
         }
       ]
     }
   }
   ```

   The helper skips the check when nothing changed since the last pass, and gives up after 5 failures in a row. If no check qualifies, skip the hook and say so.

5. Task queue. Create `.agent/queue.md` if it is missing, with this content, and add `.agent/` to `.git/info/exclude`:

   ```markdown
   # Task queue
   One task per line. `- [ ]` is waiting, `- [x]` is done, `- [!]` is blocked.

   ```

6. Report: the commands you confirmed, the ones that failed, the files you wrote, and whether the evaluator will be able to exercise the app here (for a web app, say whether a browser tool is available).
