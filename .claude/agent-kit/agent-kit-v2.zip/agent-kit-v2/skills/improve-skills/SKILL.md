---
name: improve-skills
description: Reviews accumulated feedback and proposes small edits to my global CLAUDE.md, skills and agents. Run manually, about weekly.
argument-hint: [repo paths, optional]
disable-model-invocation: true
---
Inputs: `~/.claude/feedback/inbox.md`, and the recent `eval-*.md` and `progress.json` files under `.agent/` in the repos named in $ARGUMENTS (if none are named, use the paths in `~/.claude/repos.txt`).

1. Group the feedback by the instruction file it concerns. Keep only items that say why, or that came up at least twice. Look in the evaluator reports for failures that repeat across tasks: those point at a gap in the build-loop skill or the evaluator prompt.

2. For each group, propose the smallest edit that would have prevented the problem. Write a principle with its reason, not a list of rules. Prefer deleting or narrowing an existing line over adding one. Do not propose "never" rules: write the scope and the reason instead.

3. List lines that look stale: cautions whose reason no longer holds, and lines an agent could work out from the code.

4. Show me at most 3 edits as diffs, each with the feedback behind it. Apply only the ones I approve. Before changing a file, copy it to `~/.claude/feedback/backups/<date>/`. Then move the processed lines from `inbox.md` to `inbox-done.md`.

One pass. Read each input once.
