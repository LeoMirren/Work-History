---
name: fanout
description: Runs wide, parallel work (audits, migrations, the same change in many places or repos) as a dynamic workflow with cross-checked results.
argument-hint: [task]
disable-model-invocation: true
---
Task: $ARGUMENTS

1. Decide whether this needs a workflow. With fewer than about five independent units, do the work directly or with a couple of subagents.

2. Use a workflow with four phases.
   - Discover: list the units (files, routes, packages, repos).
   - Work: one agent per unit, each with a self-contained prompt that uses absolute paths and states the check that proves its unit is done. Agents that change files work in an isolated copy.
   - Check: independent agents test the findings or changes that matter. Do not spend an agent on every unit that reports a clean pass.
   - Merge: one ranked summary with the evidence for each unit.

3. Limits. Stay within the workflow size guideline in force. For iterative searches, stop when two rounds in a row add nothing new. Use low effort or a cheaper model for well-specified unit work. A failed unit gets one retry with the checker's output, then is reported as blocked.

4. Run it on a small slice first, and report the agent count and token use before the full run.

5. If workflows are not available in this session, run the same four phases with subagents, four at a time.

6. If the run is worth repeating, tell me to save it from /workflows with `s`.
